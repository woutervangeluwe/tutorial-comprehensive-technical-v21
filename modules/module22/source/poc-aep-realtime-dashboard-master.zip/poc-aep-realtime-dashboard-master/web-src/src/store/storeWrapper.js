import React from 'react'
import { Subscribe } from 'unstated'

/**
 * A Wrapper to inject Stores into Components as props
 * @param {React.Component} Component Compoent to Render
 * @param {Array} containers Stores to be Injected
 */
const storeWrapper = (Component, storeContainers) => {
  return (props) => {
    return <Subscribe to={storeContainers}>
      { (...containers) => {
        if (!containers || !containers.length) {
          console.error('No Stores subscribed to', containers)
        }
        const stores = {}
        containers.map(container => {
          stores[container.name] = container
        })
        return <Component {...stores} {...props} />
      }}
    </Subscribe>
  }
}

export default storeWrapper
