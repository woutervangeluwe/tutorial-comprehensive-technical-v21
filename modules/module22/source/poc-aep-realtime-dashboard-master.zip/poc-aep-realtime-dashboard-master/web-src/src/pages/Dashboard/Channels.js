import React from 'react'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'
import PropTypes from 'prop-types'
import storeWrapper from '../../store/storeWrapper'
import PageStore from '../../store/page'
import { ProgressCircle } from '@adobe/react-spectrum'

class Channels extends React.Component {
  constructor (props) {
    super(props)
  }

  componentWillMount () {
    console.log('[Channels Component Will Mount]')
    if (!this.props.pageStore.state.channels) {
      this.props.pageStore.loadData('channels', 'channels')
    }
  }

  render () {
    const { pageStore } = this.props
    if (!pageStore.state.channels) {
      return <ProgressCircle
                aria-label='loading'
                isIndeterminate />
    }
    const options = {
      chart: {
        type: 'pie',
        backgroundColor: '#f0f0f0'
      },
      title: {
        text: 'Marketing Channels'
      },
      subtitle: {
        text: 'last 24 hours'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      accessibility: {
        point: {
          valueSuffix: '%'
        }
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
              enabled: false
          },
          showInLegend: true
        }
      },
      credits: {
        enabled: false
      },
      series: [{
        name: 'Proportion',
        colorByPoint: true,
        data: pageStore.state.channels.data
      }]
    }
   
    return (
      <HighchartsReact highcharts={Highcharts} options={options} />
    )
  }
}

Channels.propTypes = {
  pageStore: PropTypes.object.isRequired
}

export default storeWrapper(Channels, [PageStore])