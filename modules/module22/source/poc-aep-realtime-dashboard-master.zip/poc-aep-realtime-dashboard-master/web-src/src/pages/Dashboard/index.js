import React from 'react'
import PropTypes from 'prop-types'
import storeWrapper from '../../store/storeWrapper'
import PageStore from '../../store/page'
import { Grid, View } from '@adobe/react-spectrum'

// charts
import Viewers from './Viewers'
import Categories from './Categories'
import TopArticles from './TopArticles'
import TopVideos from './TopVideos'
import Channels from './Channels'

class Dashboard extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      pageData: null
    }
  }

  componentWillMount () {
    console.log('[Dashboard Component Will Mount]')
    this.interval = setInterval(() => {
      this.props.pageStore.loadAllData()
    }, 10000)
  }

  componentWillUnmount() {
    clearInterval(this.interval)
  }

  render () {
    return (
      <Grid
        areas={[
          'viewers viewers arts arts',
          'channels cats vids vids'
        ]}
        columns={['25%', '25%', '25%', '25%']}
        rows={['50%', '50%']}
        height='100%'
        gap='size-10'>
        <View gridArea='viewers'><Viewers /></View>
        <View gridArea='channels'><Channels /></View>
        <View gridArea='cats'><Categories /></View>
        <View gridArea='arts'><TopArticles /></View>
        <View gridArea='vids'><TopVideos /></View>
      </Grid>
    )
  }
}

Dashboard.propTypes = {
  pageStore: PropTypes.object.isRequired
}

export default storeWrapper(Dashboard, [PageStore])