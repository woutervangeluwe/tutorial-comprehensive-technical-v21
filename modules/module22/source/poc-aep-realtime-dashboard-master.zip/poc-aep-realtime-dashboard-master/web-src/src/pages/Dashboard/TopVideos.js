import React from 'react'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'
import PropTypes from 'prop-types'
import storeWrapper from '../../store/storeWrapper'
import PageStore from '../../store/page'
import { ProgressCircle } from '@adobe/react-spectrum'

class TopVideos extends React.Component {
  constructor (props) {
    super(props)
  }

  componentWillMount () {
    console.log('[TopVideos Component Will Mount]')
    if (!this.props.pageStore.state.topVideos) {
      this.props.pageStore.loadData('top-articles', 'topVideos', { type: 'video' })
    }
  }

  render () {
    const { pageStore } = this.props
    if (!pageStore.state.topVideos) {
      return <ProgressCircle
                aria-label='loading'
                isIndeterminate />
    }
    const topVideos = pageStore.state.topVideos
    const options = {
      chart: {
        type: 'bar',
        backgroundColor: '#f0f0f0'
      },
      title: {
        text: 'Top Videos'
      },
      subtitle: {
        text: 'last 24 hours'
      },
      xAxis: {
        categories: topVideos.categories,
        title: {
          text: null
        }
      },
      yAxis: {
        min: 0,
        allowDecimals: false,
        title: {
          text: 'views',
          align: 'high'
        },
        labels: {
          overflow: 'justify'
        }
      },
      plotOptions: {
        bar: {
          dataLabels: {
            enabled: true
          }
        }
      },
      legend: {
        enabled: false
      },
      credits: {
        enabled: false
      },
      series: [{
        name: 'Views',
        data: topVideos.data,
        color: '#F7A35C'
      }]
  }
   
    return (
      <HighchartsReact highcharts={Highcharts} options={options} />
    )
  }
}

TopVideos.propTypes = {
  pageStore: PropTypes.object.isRequired
}

export default storeWrapper(TopVideos, [PageStore])