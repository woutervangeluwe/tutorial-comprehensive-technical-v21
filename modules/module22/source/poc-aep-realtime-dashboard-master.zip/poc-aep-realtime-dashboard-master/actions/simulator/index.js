const request = require('request-promise')

const articlesPool = [
  {
    "articleCategoryL1": "News",
    "articleCategoryL2": "Discovery",
    "articleCategoryL3": "Space",
    "articleId": "ART001",
    "articleTitle": "The Sky at Night: Mission to Jupiter"
  }, {
    "articleCategoryL1": "News",
    "articleCategoryL2": "Health",
    "articleCategoryL3": "Covid19",
    "articleId": "ART002",
    "articleTitle": "Coronavirus infects 668 on French aircraft carrier"
  }, {
    "articleCategoryL1": "Sports",
    "articleCategoryL2": "Football",
    "articleCategoryL3": "Clubs",
    "articleId": "ART003",
    "articleTitle": "Christiano Ronaldo on the way back to Real Madrid"
  }, {
    "articleCategoryL1": "Technology",
    "articleCategoryL2": "Mobile",
    "articleCategoryL3": "Android",
    "articleId": "ART125",
    "articleTitle": "When is Android 10 released?"
  }
]

const videosPool = [
  {
    "videoCategoryL1": "Technology",
    "videoCategoryL2": "Mobile",
    "videoCategoryL3": "ios",
    "videoId": "VID001",
    "videoTitle": "The new iPhone SE"
  }, {
    "videoCategoryL1": "News",
    "videoCategoryL2": "Health",
    "videoCategoryL3": "Covid19",
    "videoId": "VID002",
    "videoTitle": "COVID-19 Pandemic: ANC Special Coverage"
  }, {
    "videoCategoryL1": "Entertainment",
    "videoCategoryL2": "Travel",
    "videoCategoryL3": "Asia",
    "videoId": "VID003",
    "videoTitle": "Top 9 Destinations in South East Asia"
  }, {
    "videoId": "VID123",
    "videoTitle": "The cultural history of the balcony",
    "videoCategoryL1": "Entertainment",
    "videoCategoryL2": "Culture",
    "videoCategoryL3": "History"
  }
]

const campaignsPool = ['', 'fb123', 'li321', 'da456', 'sa654', 'xx000']

const { v4: uuid4 } = require('uuid')

async function main (params) {
  try {
    let options = {
      method: 'POST',
      url: 'https://dcs.adobedc.net/collection/ec625a97981be256914e065e51666d8c1bf12a35c4a948654234676c646c044f',
      headers: {
        'Content-Type': 'application/json'
      },
      json: {
        "header": {
          "datasetId": "5e555124a8b3f818a8ca7825",
          "imsOrgId": "907075E95BF479EC0A495C73@AdobeOrg",
          "source": {
            "name": "Jaeger"
          },
          "schemaRef": {
            "id": "https://ns.adobe.com/experienceplatform/schemas/3e9a0247bd3fc747d92b24dc7f7c4daf",
            "contentType": "application/vnd.adobe.xed-full+json;version=1"
          }
        },
        "body": {
          "xdmMeta": {
            "schemaRef": {
              "id": "https://ns.adobe.com/experienceplatform/schemas/3e9a0247bd3fc747d92b24dc7f7c4daf",
              "contentType": "application/vnd.adobe.xed-full+json;version=1"
            }
          },
          "xdmEntity": {
            "_id": uuid4(),
            "timestamp": "2020-02-26T06:46:26Z",
            "web": {
              "webPageDetails": {
                "URL": "https://platformdemo.net/index.html",
                "name": "Luma News Home",
                "pageViews": {
                  "value": 1
                }
              }
            },
            "environment": {
              "browserDetails": {
                "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36",
                "acceptLanguage": "en"
              }
            },
            "_experienceplatform": {
              "brand": {
                "tms": "Launch",
                "ldap": "vangeluw",
                "brandName": "Luma News",
                "brandIndustry": "mediaent"
              },
              "identification": {
                "ecid": "41589721565407611634541647608857110438"
              },
              "campaign": {
                "campaignId": getCampaign()
              },
              "mediaentertainment": getMediaEntertainment()
            }
          }
        }
      }
    }
    await request(options)
    return { body: {success: 'ok'} }
  } catch (e) {
    console.log(e)
    return { statusCode: 400 }
  }
}

function getRand(max) {
  return Math.random() * max
}

function getMediaEntertainment() {
  const rand2 = getRand(2)
  const randItem = Math.floor(getRand(articlesPool.length))
  
  if(rand2 < 1) {
    return {
      article: articlesPool[randItem]
    }
  }
  return {
    video: videosPool[randItem]
  }
}

function getCampaign() {
  return campaignsPool[Math.floor(getRand(campaignsPool.length))]
}

exports.main = main