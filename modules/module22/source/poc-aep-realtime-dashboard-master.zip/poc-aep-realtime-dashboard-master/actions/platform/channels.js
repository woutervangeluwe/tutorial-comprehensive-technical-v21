const { Core } = require('@adobe/aio-sdk')
const stateLib = require('@adobe/aio-lib-state')
const { getPartitionKey } = require('../utils')

const channelsMapping = {
  li: 'LinkedIn',
  da: 'Display',
  fb: 'Facebook',
  sa: 'Search',
  em: 'Email',
  '': 'Direct'
}

async function main (params) {
  // create a Logger
  const myAppLogger = Core.Logger('main', { level: params.LOG_LEVEL })
  // 'info' is the default level if not set
  myAppLogger.info('Calling the main action')

  try {

    const state = await stateLib.init()

    const querySpec = {
      query: `SELECT COUNT(1) as y, c['value'].marketing.trackingCode as name FROM c
              GROUP BY c['value'].marketing.trackingCode`
    }
    const results = await state.query(querySpec)
    const getMapKey = (channelId) => {
      if (!channelId) return channelsMapping['']
      if (channelId.length >= 2 && channelsMapping[channelId.substr(0, 2)]) {
        return channelsMapping[channelId.substr(0, 2)]
      }
      return 'Others'
    }

    const channels = results.reduce((all, curr) => {
      const currMapKey = getMapKey(curr.name)
      // look for the current element in the prev list
      const ndx = all.findIndex(e => e.name === currMapKey)
      if (ndx > -1) {
        // if found, concat the count of the same item
        all[ndx].y += curr.y
      } else {
        // otherwise, push the item to the list
        all.push({ name: currMapKey, y: curr.y })
      }
      return all
    }, [])

    channels.sort((a, b) => b.y - a.y)

    myAppLogger.debug(channels)

    return {
      statusCode: 200,
      body: {
        data: channels
      }
    }
  } catch (error) {
    myAppLogger.error(error)
    return {
      statusCode: 500,
      body: { error: 'server error' }
    }
  }
}

exports.main = main