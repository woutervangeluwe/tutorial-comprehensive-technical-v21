const { Core } = require('@adobe/aio-sdk')
const stateLib = require('@adobe/aio-lib-state')
const topN = 10

async function main (params) {
  // create a Logger
  const myAppLogger = Core.Logger('main', { level: params.LOG_LEVEL })
  // 'info' is the default level if not set
  myAppLogger.info('Calling the main action')

  try {
    const state = await stateLib.init()

    // type could be 'article' or 'video'
    const eventType = `${params.type}View`
    console.log(eventType)

    const querySpec = {
      query: `SELECT COUNT(1) as count, c['value']._experienceplatform.interactionDetails.media.contentInteractions.id as id, c['value']._experienceplatform.interactionDetails.media.contentInteractions.title as title FROM c
              WHERE c['value']._experienceplatform.interactionDetails.media.contentInteractions != null AND c['value'].eventType = @eventType
              GROUP BY c['value']._experienceplatform.interactionDetails.media.contentInteractions.id, c['value']._experienceplatform.interactionDetails.media.contentInteractions.title`,
      parameters: [
        {
          name: '@eventType',
          value: eventType
        }
      ]
    }
    let results = await state.query(querySpec)
    console.log(results)
    results = results.filter(obj => obj.id && obj.title)
    results.sort((a,b) => (a.count < b.count) ? 1 : -1)
    const categories = []
    const data = []
    results.slice(0, topN).map(obj => {
      if(obj.id && obj.title) {
        categories.push(obj.title)
        data.push(obj.count)
      }
    })

    return {
      statusCode: 200,
      body: {
        categories,
        data
      }
    }
  } catch (error) {
    myAppLogger.error(error)
    return {
      statusCode: 500,
      body: { error: 'server error' }
    }
  }
}

exports.main = main