const { Core } = require('@adobe/aio-sdk')
const stateLib = require('@adobe/aio-lib-state')
const { getPartitionKey } = require('../utils')

async function main (params) {
  // create a Logger
  const myAppLogger = Core.Logger('main', { level: params.LOG_LEVEL })
  // 'info' is the default level if not set
  myAppLogger.info('Calling the main action')

  try {
    const state = await stateLib.init()

    const querySpec = {
      query: `SELECT COUNT(1) as y, c['value']._experienceplatform.interactionDetails.media.contentInteractions.categoryL1 as l1, c['value']._experienceplatform.interactionDetails.media.contentInteractions.categoryL2 as l2, c['value']._experienceplatform.interactionDetails.media.contentInteractions.categoryL3 as l3 FROM c
              WHERE c['value']._experienceplatform.interactionDetails.media.contentInteractions != null
              GROUP BY c['value']._experienceplatform.interactionDetails.media.contentInteractions.categoryL1, c['value']._experienceplatform.interactionDetails.media.contentInteractions.categoryL2, c['value']._experienceplatform.interactionDetails.media.contentInteractions.categoryL3`
    }
    const queryResults = await state.query(querySpec)
    const allResults = queryResults.filter(item => !!item.l1)
    const results = allResults.reduce((all, curr) => {
      // look for the current element in the prev list
      const ndx = all.findIndex(e => e.l1 === curr.l1 && e.l2 === curr.l2 && e.l3 === curr.l3)
      if (ndx > -1) {
        // if found, concat the count of the same item
        all[ndx].y += curr.y
      } else {
        // otherwise, push the item to the list
        all.push(curr)
      }
      return all
    }, [])

    const categories = results.reduce((all, obj) => {
      const l1Index = all.findIndex(e => e.level === 1 && e.name === obj.l1)
      const l2Index = (l1Index === -1) ? -1 : all.findIndex(e => e.level === 2 && e.name === obj.l2 && e.parent === all[l1Index].id)
      const i = all.length
      if (l1Index === -1) {
        // add all new nodes
        all.push({name: obj.l1, id: i.toString(), level: 1, parent: all[0].id})
        all.push({name: obj.l2, id: (i + 1).toString(), level: 2, parent: i.toString()})
        all.push({name: obj.l3, id: (i + 2).toString(), level: 3, parent: (i + 1).toString(), value: obj.y})
      } else if (l2Index === -1) {
        // only add l2 and l3 as new nodes, l2 as child of existing l1
        all.push({name: obj.l2, id: i.toString(), level: 2, parent: all[l1Index].id})
        all.push({name: obj.l3, id: (i + 1).toString(), level: 3, parent: i.toString(), value: obj.y})
      } else {
        // only add l3 as new node as child of existing l2
        all.push({name: obj.l3, id: i.toString(), level: 3, parent: all[l2Index].id, value: obj.y})
      }
      return all
    }, [{
      name: 'Total',
      id: '0',
      color: 'transparent'
    }])

    myAppLogger.debug(categories)

    return {
      statusCode: 200,
      body: {
        data: categories
      }
    }
  } catch (error) {
    myAppLogger.error(error)
    return {
      statusCode: 500,
      body: { error: 'server error' }
    }
  }
}

exports.main = main